import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {ObservatoryDemo} from '../../reference-apps/versioned-risk-scoring/demo/demo-engine.mjs';

const out='build/demo-tester-011bb66';fs.mkdirSync(out,{recursive:true});
const catalog=JSON.parse(fs.readFileSync('build/observatory-demo/catalog.json'));
const head=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim();
assert.equal(head,'011bb66aba9ef89af4aa37dc379cd4e826d95b39');
assert.equal(catalog.sourceRevision,head);
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const readLf=f=>fs.readFileSync(f,'utf8').replaceAll('\r\n','\n');
const checks=[];
const check=(name,fn)=>{fn();checks.push({name,result:'PASS'});};
const make=()=>new ObservatoryDemo(catalog,()=> '2026-10-03T00:00:00Z');
const last=m=>m.state.requests.at(-1);
const setup=(m,v)=>{m.act('install',{version:v});m.act('activate',{version:v});};
const results=[];
check('Every current version/sample policy branch',()=>{
  const expected={v1:{LOW:['0.09','ALLOW'],STANDARD:['0.73','REVIEW'],HIGH:['0.80','REVIEW']},v2:{LOW:['0.13','ALLOW'],STANDARD:['0.85','REJECT'],HIGH:['0.93','REJECT']}};
  for(const v of ['v1','v2'])for(const sample of ['LOW','STANDARD','HIGH']){
    const m=make();setup(m,v);m.act('invoke',{sample});const r=last(m);
    assert.equal(r.score.toFixed(2),expected[v][sample][0]);assert.equal(r.decision,expected[v][sample][1]);
    assert.equal(r.executionBinding.definition.definitionDigest,catalog.definitions.find(d=>d.version===v).digest);
    assert.equal(r.wireCalled,false);results.push({version:v,sample,score:r.score,signal:r.signal,decision:r.decision});
  }
});
check('STANDBY does not authorize rollback and an unavailable first version cannot rollback',()=>{
  const m=make();m.act('install',{version:'v1'});m.act('install',{version:'v2'});m.act('activate',{version:'v2'});
  assert.equal(m.state.canRollback,false);m.act('invoke',{mode:'crash'});assert.equal(m.state.activeEligible,false);
  assert.throws(()=>m.act('rollback'),/previously active/);m.act('activate',{version:'v1'});assert.equal(m.state.canRollback,true);
});
check('Three independent held realization pins survive cutover and fresh rollback',()=>{
  const m=make();setup(m,'v1');m.act('install',{version:'v2'});
  const a=m.act('invoke',{sample:'STANDARD',mode:'hold'}).id;const an=last(m).executionBinding.realization.launchNonce;
  m.act('activate',{version:'v2'});const b=m.act('invoke',{sample:'HIGH',mode:'hold'}).id;
  m.act('rollback');const c=m.act('invoke',{sample:'LOW',mode:'hold'}).id;
  assert.notEqual(last(m).executionBinding.realization.launchNonce,an);
  assert.equal(m.state.deployments.filter(d=>d.alive).length,3);
  assert.throws(()=>m.act('invoke'),/Release/);
  for(const id of [b,a,c]){m.act('release',{requestId:id});assert.throws(()=>m.act('release',{requestId:id}),/No held/);}
  assert.deepEqual(m.state.requests.map(r=>[r.version,r.decision]),[['v1','REVIEW'],['v2','REJECT'],['v1','ALLOW']]);
  assert.ok(m.state.deployments.filter(d=>d.state==='RETIRED').every(d=>!d.alive&&d.outstandingPins===0));
});
check('UNKNOWN/null/WITHHELD and original pin remain unchanged across both rollback directions',()=>{
  const m=make();setup(m,'v1');m.act('install',{version:'v2'});m.act('activate',{version:'v2'});m.act('invoke',{mode:'crash'});
  const old=JSON.stringify(last(m));m.act('rollback');m.act('invoke',{sample:'LOW'});m.act('rollback');m.act('invoke',{sample:'HIGH'});
  assert.equal(JSON.stringify(m.state.requests[0]),old);assert.equal(m.state.requests[0].score,null);assert.equal(m.state.requests[0].decision,'WITHHELD');
  assert.equal(new Set(m.state.deployments.map(d=>d.realization.launchNonce)).size,m.state.deployments.length);
});
check('Close terminates every held request without awarding a decision, snapshot receipt detached, reset reinitializes model',()=>{
  const m=make();setup(m,'v1');m.act('install',{version:'v2'});m.act('invoke',{mode:'hold'});m.act('activate',{version:'v2'});m.act('invoke',{mode:'hold'});
  assert.throws(()=>m.receipt(),/Close/);m.act('close');
  assert.ok(m.state.requests.every(r=>r.score===null&&r.decision==='WITHHELD'&&!r.canRelease));
  assert.equal(m.state.observedLiveWorkers,0);assert.equal(m.state.canClose,false);assert.equal(m.state.canRollback,false);
  assert.throws(()=>m.act('release',{requestId:'R001'}),/Reset/);
  const r=m.receipt();assert.match(r.scope,/No Java host, Python worker/);assert.equal(r.schemaVersion,'jpyxis.io/frontend-demo-receipt/v1alpha1');
  r.requests[0].decision='ALTERED';assert.equal(m.state.requests[0].decision,'WITHHELD');m.reset();assert.deepEqual(m.state.requests,[]);assert.deepEqual(m.state.deployments,[]);assert.equal(m.state.activeVersion,null);
});
check('Relative public entry, simulation copy, no loopback API or host credentials',()=>{
  const html=readLf('build/observatory-demo/index.html'),js=readLf('build/observatory-demo/app.js');
  assert.ok(!js.includes('/api/'));assert.ok(!js.includes('X-Reference-Token'));assert.ok(!js.includes('setInterval'));
  assert.match(html,/INTERACTIVE DEMO · BROWSER ONLY/);assert.match(html,/no Java or Python process runs/);assert.match(js,/BROWSER SIMULATION/);
  for(const asset of ['style.css','demo.css','app.js'])assert.ok(html.includes('./'+asset));
  assert.match(js,/frontend-demo-receipt/); // model import path must use the distinct demo engine; built model contains schema.
});
check('Publication binds normalized host assets and copied style has no drift',()=>{
  const publication=JSON.parse(fs.readFileSync('build/observatory-demo/publication.json'));
  assert.equal(publication.siteRevision,head);
  for(const f of publication.sourceAssets)assert.equal(f.sha256Lf,sha(readLf(f.path)));
  assert.equal(readLf('build/observatory-demo/style.css'),readLf('reference-apps/versioned-risk-scoring/host-java/src/main/resources/observatory/style.css'));
  assert.equal(execFileSync('git',['diff','--name-only','09ac1d4caea32ff1ce251da8acdc56cbebb5020e..'+head,'--','reference-apps/versioned-risk-scoring/host-java/src/main/resources/observatory'],{encoding:'utf8'}).trim(),'');
});
fs.writeFileSync(path.join(out,'independent-checks.json'),JSON.stringify({head,checks,results},null,2)+'\n');
console.log(JSON.stringify({head,checks,results},null,2));
