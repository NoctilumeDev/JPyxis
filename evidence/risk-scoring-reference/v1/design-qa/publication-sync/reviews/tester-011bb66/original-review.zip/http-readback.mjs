import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const files=['index.html','app.js','style.css','demo.css','demo-engine.mjs','catalog.json','publication.json'];
const rows=[];
for(const file of files){
  const r=await fetch('http://127.0.0.1:8768/observatory-demo/'+file);
  assert.equal(r.status,200);const bytes=Buffer.from(await r.arrayBuffer());
  const local=fs.readFileSync('build/observatory-demo/'+file);assert.ok(bytes.equals(local));
  rows.push({file,status:r.status,bytes:bytes.length,sha256:sha(bytes),byteEqualToBuild:true});
}
const publication=JSON.parse(fs.readFileSync('build/observatory-demo/publication.json'));
assert.equal(publication.siteRevision,'011bb66aba9ef89af4aa37dc379cd4e826d95b39');
fs.writeFileSync('build/demo-tester-011bb66/http-readback.json',JSON.stringify({revision:publication.siteRevision,base:'http://127.0.0.1:8768/observatory-demo/',rows},null,2)+'\n');
console.log(JSON.stringify({revision:publication.siteRevision,rows},null,2));
